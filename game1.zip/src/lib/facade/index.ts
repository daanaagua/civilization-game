export { getVisibleFromRegistry } from './visibility-facade';
export type { VisibilityInput, VisibilityOutput } from './visibility-facade';