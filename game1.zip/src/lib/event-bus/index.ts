export { EventBus, GlobalEventBus } from './event-bus';
export type { DefaultEventMap, Handler } from './event-bus';